#include <string.h>

#ifndef CONFIG_HAVE_STRNDUP

char *strndup(const char *s, size_t n);

#endif
